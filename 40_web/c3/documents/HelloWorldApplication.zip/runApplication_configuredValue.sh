java -cp .:./c3.jar -Dname="Uzy" c3sample.HelloWorldApplication 
