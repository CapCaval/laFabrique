java -cp .:./c3.jar c3sample.HelloWorldApplication -help
