package c3sample;

import org.capcaval.c3.application.Application;
import org.capcaval.c3.application.annotations.AppInformation;
import org.capcaval.c3.application.annotations.AppProperty;


@AppInformation (version="1.0", about = "This a Hello world application with C³")
public class HelloWorldApplication extends Application {
	@AppProperty(comment="Application which salute anyone.")
	String name = "World";
	
	public static void main(String[] args) {
		HelloWorldApplication app = new HelloWorldApplication();
		app.launchApplication(args);
	}
	
	@Override
	public void notifyApplicationToBeRun(String applicationDescrition, String componentsDescription) {
		System.out.println("Application started");
		
		// use your component
		System.out.println("Hello " + this.name + "!");
	}

	@Override
	public void notifyApplicationToBeClosed() {
		System.out.println("bye bye, application closed");
	}
}
