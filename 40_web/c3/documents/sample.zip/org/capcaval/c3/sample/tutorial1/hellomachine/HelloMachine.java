package org.capcaval.c3.sample.tutorial1.hellomachine;

import org.capcaval.c3.component.Component;

public interface HelloMachine extends Component{

}
