package org.capcaval.c3.sample.tutorial1.hellomachine;

import org.capcaval.c3.component.ComponentService;


public interface HelloMachineServices extends ComponentService{
	
	public String salute(final String name);

}
