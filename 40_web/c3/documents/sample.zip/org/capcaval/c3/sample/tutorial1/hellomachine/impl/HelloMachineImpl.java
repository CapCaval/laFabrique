package org.capcaval.c3.sample.tutorial1.hellomachine.impl;

import org.capcaval.c3.sample.tutorial1.hellomachine.HelloMachine;
import org.capcaval.c3.sample.tutorial1.hellomachine.HelloMachineServices;


public class HelloMachineImpl implements HelloMachine, HelloMachineServices{

	@Override
	public String salute(String name) {
		// compute the salute with the given name
		return "Hello " + name + " !";
	}


	

}
