package org.capcaval.c3.sample.tutorial1;

import org.capcaval.c3.componentmanager.ComponentManager;
import org.capcaval.c3.sample.tutorial1.hellomachine.HelloMachineServices;
import org.capcaval.c3.sample.tutorial1.hellomachine.impl.HelloMachineImpl;

public class HelloMachineMain {

	public static void main(String[] args) {
		
		// get the C3 component manager
		ComponentManager cm = ComponentManager.componentManager;

		// start the application, with the given component
		cm.startApplication(HelloMachineImpl.class);
	
		// retrieve the service of the created component
		HelloMachineServices hms = cm.getComponentService(HelloMachineServices.class);
		// use the service to retrieve a salute sentence
		String sentence = hms.salute("world");
		
		// display the sentence to the system output 
		System.out.println(sentence);
	}
}
